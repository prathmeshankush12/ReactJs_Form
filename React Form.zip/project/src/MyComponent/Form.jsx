import { useState } from 'react'
import './Abc.css'

function Form() {
  const [values, setValues] = useState({
    firstname: '',
    lastname: '',
    email: '',
    contact: '',
    gender: '',
    Skills: '',
    resume: '',
    Image: '',
    about: ''

  });

  const handleChanges = (e) => {
    setValues({ ...values, [e.target.name]: [e.target.value] });


  }
  const handleSubmit = (e) => {
    e.preventDefault()
    console.log(values)


  }



  return (

    <form onSubmit={handleSubmit} >

      <div className='Container'>
        <h1>React Form</h1>

        <label htmlFor="firstname">First Name*</label>
        <input type="text" id='firstname' placeholder='Enter First Name' name="firstname"
          onChange={(e) => handleChanges(e)} required />


        <label htmlFor="lastname">Last Name*</label>
        <input type="text" id='lastname' placeholder='Enter Last name' name="lastname"
          onChange={(e) => handleChanges(e)} required />


        <label htmlFor="email">Email*</label>
        <input type='email' id='email' placeholder='Enter Your Contact' name="email"
          onChange={(e) => handleChanges(e)} required />


        <label htmlFor="contact">Contact*</label>
        <input type="text" id='contact' placeholder='Enter Your Contact' name="contact"
          onChange={(e) => handleChanges(e)} required />


        <label htmlFor="gender">Gender*</label>
        <input type='radio' id='gender' name="gender" onChange={(e) => handleChanges(e)} />Male
        <input type='radio' name='gender' onChange={(e) => handleChanges(e)} />Female
        <input type='radio' name='gender' onChange={(e) => handleChanges(e)} />Other


        <label htmlFor="Skills">Skills*</label>
        <select name="Skills" id='Skills' onChange={(e) => handleChanges(e)} >
          <option value="Select">Select</option>
          <option value="C Programming">C Programming</option>
          <option value=".NET">.NET</option>
          <option value="ASP .NET">ASP .NET</option>
          <option value="React.Js">React.Js</option>
          <option value="Java">Java</option>
          <option value="C++">C++</option>
        </select>


        <label htmlFor="resume">Resume*</label>
        <input type='file' id='resume' placeholder='Select Resume' name="resume" onChange={(e) => handleChanges(e)}  required />


        <label htmlFor="Image">Image*</label>
        <input type='file' id='Image' placeholder='Enter Image ' name="Image" onChange={(e) => handleChanges(e)} required />


        <label htmlFor="about">About*</label>
        <textarea name="about" id='about' cols={30} rows={10} placeholder='Enter description' onChange={(e) => handleChanges(e)}></textarea>


        <button type='Reset'>Reset</button>
        <button type='Submit'>Submit</button>

      </div>
    </form>

  );
}
export default Form;


import Form from "./MyComponent/Form"

function App() {


  return (
    <>
      <Form></Form>
    </>
  )
}

export default App
